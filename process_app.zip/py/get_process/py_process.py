# import matplotlib.pyplot as plt
import numpy as np


def function(arg1, arg2):
    return arg1 + np.exp(arg2)


print('Works!')

print(f'An array -> {np.arange(0,101,1)}')
